import { type ActionType, type AlignType, type BuildInPlacements, type TriggerProps, type TriggerRef } from '@rc-component/trigger';
import React from 'react';
import Placements from './placements';
export interface DropdownProps extends Pick<TriggerProps, 'getPopupContainer' | 'children' | 'mouseEnterDelay' | 'mouseLeaveDelay' | 'onPopupAlign' | 'builtinPlacements' | 'autoDestroy'> {
    minOverlayWidthMatchTrigger?: boolean;
    arrow?: boolean;
    onVisibleChange?: (visible: boolean) => void;
    onOverlayClick?: (e: Event) => void;
    prefixCls?: string;
    transitionName?: string;
    overlayClassName?: string;
    openClassName?: string;
    animation?: string;
    align?: AlignType;
    overlayStyle?: React.CSSProperties;
    placement?: keyof typeof Placements;
    placements?: BuildInPlacements;
    overlay?: (() => React.ReactElement) | React.ReactElement;
    trigger?: ActionType | ActionType[];
    alignPoint?: boolean;
    showAction?: ActionType[];
    hideAction?: ActionType[];
    visible?: boolean;
    autoFocus?: boolean;
}
declare const Dropdown: React.ForwardRefExoticComponent<DropdownProps & React.RefAttributes<TriggerRef>>;
export default Dropdown;
