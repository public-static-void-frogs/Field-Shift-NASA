import * as React from 'react';
import type { CustomizeComponent } from '../interface';
export interface ExpandedRowProps {
    prefixCls: string;
    component: CustomizeComponent;
    cellComponent: CustomizeComponent;
    className: string;
    expanded: boolean;
    children: React.ReactNode;
    colSpan: number;
    isEmpty: boolean;
    stickyOffset?: number;
}
declare const ExpandedRow: React.FC<ExpandedRowProps>;
export default ExpandedRow;
