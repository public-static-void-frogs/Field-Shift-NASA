import type { ReactNode } from 'react';
import type { TourProps as RCTourProps, TourStepProps as RCTourStepProps } from '@rc-component/tour';
import type { GenerateSemantic } from '../_util/hooks/useMergeSemantic/semanticType';
import type { ButtonProps } from '../button';
export type TourSemanticType = {
    classNames?: {
        root?: string;
        cover?: string;
        close?: string;
        mask?: string;
        section?: string;
        footer?: string;
        actions?: string;
        indicator?: string;
        indicators?: string;
        header?: string;
        title?: string;
        description?: string;
    };
    styles?: {
        root?: React.CSSProperties;
        cover?: React.CSSProperties;
        close?: React.CSSProperties;
        mask?: React.CSSProperties;
        section?: React.CSSProperties;
        footer?: React.CSSProperties;
        actions?: React.CSSProperties;
        indicator?: React.CSSProperties;
        indicators?: React.CSSProperties;
        header?: React.CSSProperties;
        title?: React.CSSProperties;
        description?: React.CSSProperties;
    };
};
export type TourSemanticAllType = GenerateSemantic<TourSemanticType, TourProps>;
export interface TourProps extends Omit<RCTourProps, 'renderPanel' | 'classNames' | 'styles'> {
    steps?: TourStepProps[];
    prefixCls?: string;
    current?: number;
    keyboard?: boolean;
    indicatorsRender?: (current: number, total: number) => ReactNode;
    actionsRender?: (originNode: ReactNode, info: {
        current: number;
        total: number;
    }) => ReactNode;
    type?: 'default' | 'primary';
    classNames?: TourSemanticAllType['classNamesAndFn'];
    styles?: TourSemanticAllType['stylesAndFn'];
    className?: string;
    style?: React.CSSProperties;
}
export interface TourStepProps extends Omit<RCTourStepProps, 'styles' | 'classNames'> {
    cover?: ReactNode;
    nextButtonProps?: {
        children?: ReactNode;
        onClick?: ButtonProps['onClick'];
        className?: string;
        style?: React.CSSProperties;
    };
    prevButtonProps?: {
        children?: ReactNode;
        onClick?: ButtonProps['onClick'];
        className?: string;
        style?: React.CSSProperties;
    };
    type?: 'default' | 'primary';
    classNames?: TourSemanticAllType['classNames'];
    styles?: TourSemanticAllType['styles'];
}
export interface TourLocale {
    Next: string;
    Previous: string;
    Finish: string;
}
