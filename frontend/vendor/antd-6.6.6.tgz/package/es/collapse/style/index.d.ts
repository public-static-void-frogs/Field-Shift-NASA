import type { CSSProperties } from 'react';
import type { CSSObject } from '@ant-design/cssinjs';
import type { FullToken, GenerateStyle, GetDefaultToken } from '../../theme/internal';
/** Component only token. Which will handle additional calculation of alias token */
export interface ComponentToken {
    /**
     * @desc 折叠面板头部内边距
     * @descEN Padding of header
     */
    headerPadding: CSSProperties['padding'];
    /**
     * @desc 小号折叠面板头部内边距
     * @descEN Padding of small header
     */
    headerPaddingSM: CSSProperties['padding'];
    /**
     * @desc 大号折叠面板头部内边距
     * @descEN Padding of large header
     */
    headerPaddingLG: CSSProperties['padding'];
    /**
     * @desc 折叠面板头部背景
     * @descEN Background of header
     */
    headerBg: string;
    /**
     * @desc 折叠面板内容内边距
     * @descEN Padding of content
     */
    contentPadding: CSSProperties['padding'];
    /**
     * @desc 小号折叠面板内容内边距
     * @descEN Padding of small content
     */
    contentPaddingSM: CSSProperties['padding'];
    /**
     * @desc 大号折叠面板内容内边距
     * @descEN Padding of large content
     */
    contentPaddingLG: CSSProperties['padding'];
    /**
     * @desc 折叠面板内容背景
     * @descEN Background of content
     */
    contentBg: string;
    /**
     * @desc 简约风格折叠面板的内容内边距
     * @descEN Padding of content in borderless style
     */
    borderlessContentPadding: CSSProperties['padding'];
    /**
     * @desc 简约风格折叠面板的内容背景
     * @descEN Background of content in borderless style
     */
    borderlessContentBg: string;
}
type CollapseToken = FullToken<'Collapse'> & {
    /**
     * @desc 折叠面板边框圆角
     * @descEN Border radius of collapse panel
     */
    collapsePanelBorderRadius: number;
};
export declare const genBaseStyle: GenerateStyle<CollapseToken, CSSObject>;
export declare const prepareComponentToken: GetDefaultToken<'Collapse'>;
declare const _default: (prefixCls: string, rootCls?: string) => readonly [string, string];
export default _default;
