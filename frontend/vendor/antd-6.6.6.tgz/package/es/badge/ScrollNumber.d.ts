import * as React from 'react';
export interface ScrollNumberProps {
    prefixCls?: string;
    className?: string;
    motionClassName?: string;
    count?: string | number | null;
    children?: React.ReactElement;
    component?: React.ComponentType<React.HTMLAttributes<HTMLElement>>;
    style?: React.CSSProperties;
    title?: string | number | null;
    show: boolean;
}
declare const ScrollNumber: React.ForwardRefExoticComponent<ScrollNumberProps & React.RefAttributes<HTMLElement>>;
export default ScrollNumber;
