import * as React from 'react';
import type { Settings } from '@ant-design/react-slick';
export type CarouselEffect = 'scrollx' | 'fade';
export type DotPlacement = 'top' | 'bottom' | 'start' | 'end';
export interface CarouselProps extends Omit<Settings, 'dots' | 'dotsClass' | 'autoplay' | 'verticalSwiping'> {
    effect?: CarouselEffect;
    style?: React.CSSProperties;
    prefixCls?: string;
    rootClassName?: string;
    id?: string;
    slickGoTo?: number;
    /** @deprecated Please use `dotPlacement` instead  */
    dotPosition?: DotPlacement | 'left' | 'right';
    dotPlacement?: DotPlacement;
    children?: React.ReactNode;
    dots?: boolean | {
        className?: string;
    };
    waitForAnimate?: boolean;
    autoplay?: boolean | {
        dotDuration?: boolean;
    };
}
export interface CarouselRef {
    nativeElement: HTMLDivElement;
    goTo: (slide: number, dontAnimate?: boolean) => void;
    next: () => void;
    prev: () => void;
    autoPlay: (playType?: 'update' | 'leave' | 'blur') => void;
    innerSlider: any;
}
declare const Carousel: React.ForwardRefExoticComponent<CarouselProps & React.RefAttributes<CarouselRef>>;
export default Carousel;
