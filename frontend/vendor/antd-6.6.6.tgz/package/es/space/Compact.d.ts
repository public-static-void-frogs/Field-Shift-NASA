import * as React from 'react';
import type { Orientation } from '../_util/hooks';
import type { DirectionType } from '../config-provider';
import type { SizeType } from '../config-provider/SizeContext';
export interface SpaceCompactItemContextType {
    compactSize?: SizeType;
    compactDirection?: 'horizontal' | 'vertical';
    isFirstItem?: boolean;
    isLastItem?: boolean;
}
export declare const SpaceCompactItemContext: React.Context<SpaceCompactItemContextType | null>;
export declare const useCompactItemContext: (prefixCls: string, direction: DirectionType) => {
    compactSize: SizeType;
    compactDirection: "horizontal" | "vertical" | undefined;
    compactItemClassnames: string;
};
export declare const NoCompactStyle: React.FC<Readonly<React.PropsWithChildren>>;
export interface SpaceCompactProps extends React.HTMLAttributes<HTMLDivElement> {
    prefixCls?: string;
    size?: SizeType;
    /** @deprecated please use `orientation` instead */
    direction?: Orientation;
    orientation?: Orientation;
    vertical?: boolean;
    block?: boolean;
    rootClassName?: string;
}
export interface SpaceCompactRef {
    nativeElement: HTMLDivElement;
}
declare const Compact: React.ForwardRefExoticComponent<SpaceCompactProps & React.RefAttributes<SpaceCompactRef>>;
export default Compact;
