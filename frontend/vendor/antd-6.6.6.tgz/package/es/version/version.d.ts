declare const _default: "6.6.6";
export default _default;
